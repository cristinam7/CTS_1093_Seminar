package ro.ase.csie.cts.g1093.mironcristina.assignment3.factory;

public enum ServerType {
	FAX, STREAMING
}
