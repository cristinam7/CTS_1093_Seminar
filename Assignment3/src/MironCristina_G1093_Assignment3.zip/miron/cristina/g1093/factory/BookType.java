package miron.cristina.g1093.factory;

public enum BookType {
	CLASSIC,
	ENCYCLOPEDIA,  
	DICTIONARY,
	MAGAZINE
}
