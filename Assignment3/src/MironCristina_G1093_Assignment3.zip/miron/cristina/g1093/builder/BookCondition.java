package miron.cristina.g1093.builder;

public enum BookCondition {
	NEW, 
	USED, 
	DAMAGED
}
